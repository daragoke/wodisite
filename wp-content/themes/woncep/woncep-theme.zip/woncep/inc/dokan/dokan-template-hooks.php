<?php

//add_action('woncep_woocommerce_single_product_dokan', 'woncep_dokan_sold_store', 1);

remove_action( 'elementor/widgets/wordpress/widget_args', 'dokan_depricated_elementor_store_widgets', 10, 2 );
