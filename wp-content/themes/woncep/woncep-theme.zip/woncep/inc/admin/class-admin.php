<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Woncep_Admin' ) ) :
	/**
	 * The Woncep admin class
	 */
	class Woncep_Admin {

	}

endif;

return new Woncep_Admin();
