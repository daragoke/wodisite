class WoncepTheme {

}

$(document).ready(function () {
    new WoncepTheme();
})
