<div class="copyright-bar">
	<div class="container">
		<div class="row">
			<div class="column-12">
				<?php woncep_credit(); ?>
			</div>
		</div>
	</div>
</div>
