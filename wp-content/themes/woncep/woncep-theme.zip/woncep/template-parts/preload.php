<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//s.w.org">
<?php global $woncep_version; ?>

<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( 'assets/fonts/icons/woncep-icon-' . $woncep_version . '.woff2' ) ); ?>" as="font" crossorigin>
<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( 'assets/fonts/new/CerebriSansPro-Medium.woff2' ) ) ?>" as="font" crossorigin>
<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( 'assets/fonts/new/CerebriSansPro-Regular.woff2' ) ) ?>" as="font" crossorigin>
