import Module from '../../modules/site-editor/assets/js/site-editor';

new Module();
